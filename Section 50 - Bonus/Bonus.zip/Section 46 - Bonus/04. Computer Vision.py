# https://chat.openai.com/share/7a5da424-0260-49cf-943b-0ed17c8fb691

import cv2
import face_recognition
import os
import numpy as np
from albumentations import Compose, HorizontalFlip, Rotate, RandomBrightnessContrast

# Define your image augmentation pipeline
augmentor = Compose([
    HorizontalFlip(p=0.5),
    Rotate(limit=15, p=0.5),
    RandomBrightnessContrast(p=0.2)
])

def preprocess_image(image_path):
    # Read image
    image = cv2.imread(image_path)
    
    # Convert to RGB
    rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    # Detect face and extract embeddings
    face_locations = face_recognition.face_locations(rgb_image)
    if len(face_locations) > 0:
        face_encoding = face_recognition.face_encodings(rgb_image, face_locations)[0]
    else:
        return None, None
    
    # Augment image
    augmented_image = augmentor(image=rgb_image)['image']
    
    return face_encoding, augmented_image

# Prepare dataset
data_dir = "path_to_images"
labels = []
embeddings = []
for filename in os.listdir(data_dir):
    if filename.endswith(".jpg"):
        label = filename.split('_')[0]  # Assuming label is the first part of filename
        image_path = os.path.join(data_dir, filename)
        face_encoding, augmented_image = preprocess_image(image_path)
        
        if face_encoding is not None:
            embeddings.append(face_encoding)
            labels.append(label)

# Convert to numpy arrays
X = np.array(embeddings)
y = np.array(labels)

from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.models import Model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.utils import to_categorical

# Encoding labels
label_encoder = LabelEncoder()
y_encoded = to_categorical(label_encoder.fit_transform(y))

# Split data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=42)

# Load the pre-trained MobileNetV2 model
base_model = MobileNetV2(weights='imagenet', include_top=False, input_shape=(224, 224, 3))

# Add custom layers on top of base model
x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dense(1024, activation='relu')(x)
predictions = Dense(len(label_encoder.classes_), activation='softmax')(x)

# Define the full model
model = Model(inputs=base_model.input, outputs=predictions)

# Freeze the layers of the base model
for layer in base_model.layers:
    layer.trainable = False

# Compile the model
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Train the model
model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=10, batch_size=32)

# Evaluate the model on test data
loss, accuracy = model.evaluate(X_test, y_test)
print(f"Test Accuracy: {accuracy * 100:.2f}%")

def recognize_employee(new_image_path):
    new_face_encoding, _ = preprocess_image(new_image_path)
    if new_face_encoding is None:
        return "No face detected"
    
    # Find the best match
    results = face_recognition.compare_faces(X, new_face_encoding)
    distances = face_recognition.face_distance(X, new_face_encoding)
    
    if True in results:
        best_match_index = np.argmin(distances)
        label = label_encoder.inverse_transform([np.argmax(y[best_match_index])])[0]
        return f"Employee: {label}"
    else:
        return "Employee not recognized"

# Example usage
print(recognize_employee("path_to_new_image.jpg"))